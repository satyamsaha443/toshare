// Usage: https://github.com/themustafaomar/jsvectormap
import "jsvectormap"
import "./vector-maps/world.js"